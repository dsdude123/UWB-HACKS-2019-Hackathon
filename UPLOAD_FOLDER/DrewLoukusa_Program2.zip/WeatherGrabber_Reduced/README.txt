Drew Loukusa 
CSS 490: Cloud Computing
Program 2: REST


To Build:
-------------------------------------------------------------------------------
You must run 'Developer Command Prompt' in my project directory and then run:

	msbuild.exe 



WeatherGrabber.exe will be found in 'WeatherGrabber\bin\debug'.


To Run:
-------------------------------------------------------------------------------
On the command line,

	.\WeatherGrabber.exe -c [city_name]
	.\WeatherGrabber.exe --help 			//For all the optional flags
	

Notes:
-------------------------------------------------------------------------------

I am using MSBuild to build my program. It is found in multiple locations and I'm checking two of those:

	C:\Windows\Microsoft.NET\Framework\v4.0.30319\
	C:\Program Files (x86)\MSBuild\14.0\Bin\
	
If the build fails, please find where your MSBuild.exe is and pass it in as arg 1 to 'make.bat': 

	.\make.bat C:\path\path\MSBuild.exe
	
I'm using 4.6.1 Version of the .NET Framework. 

