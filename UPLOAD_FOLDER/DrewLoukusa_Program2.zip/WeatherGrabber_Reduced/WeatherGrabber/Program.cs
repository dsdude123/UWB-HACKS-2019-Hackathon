﻿using System;
using System.Threading;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Net.Http;

namespace WeatherGrabber
{
    class Program
    {
        private const string UriString = "http://api.openweathermap.org/data/2.5/";
        private const string MYAPPID = "d2e822eabb1d165f04e6bb11b50d6c57";
        enum API_STATUS
        {
            OK,
            CITY_NOT_FOUND,
            API_UNAVAILABLE,
        }
        static int Main(string[] args)
        {
            Console.Clear();
            string city = null;
            bool first_pass = true;
            bool single_instance = true;          
            int[] backoff_intervals = { 0, 10, 60, 600 };

            //Weather details:
            float temp = 0;
            float pressure = 0;
            float wind_speed = 0;
            float temp_min = 0;
            float temp_max = 0;
            float humidity = 0;
            int visibility = 0;

            string description = "";

            //Parse arguments:
            if( !ParseArgs( args, out city, out single_instance ))
                return 1;

            //Get the current position of the cursor:
            int home_col = Console.CursorLeft;
            int home_row = Console.CursorTop;

            //Print header for first time:
            PrintHeader();

            //Do everything at least once:
            do
            {
                //Get the city (if we need to) and print the header:               
                //Only ask for a city if a city wasn't set on launch:
                Console.Clear();
                PrintHeader();
                if(city == null || !first_pass)
                    city = GetCityFromUser();

                //Grab the data and print it out.     
                string result = "";
                //Call it and back off if its not available:
                bool reached_api = CallAPIwithBackoff( city, backoff_intervals, out result );
                if(!reached_api) {
                    return 1;
                }
                if( result != "" )
                {
                    ParseJson( result,  out temp,
                                        out pressure,
                                        out wind_speed,
                                        out temp_min,
                                        out temp_max,
                                        out humidity,
                                        out visibility,
                                        out description);
                    PrintWeatherInfo(   temp,
                                        pressure,
                                        wind_speed,
                                        city,
                                        temp_min,
                                        temp_max,
                                        humidity,
                                        visibility,
                                        description );
                }
               
                //If program was launched in single instance mode, exit here. 
                if (single_instance) return 0;

                //If we're NOT in single instance mode, let the user try again:
                PrintLn("Type 'new' key to enter a diffrent city or 'exit' to exit.");
                while (true)
                { //Accept input until we get correct input.
                    string opt = Console.ReadLine();
                    if (opt == "new") { break; }
                    if (opt == "exit") { return 0; }
                }
                if( first_pass ) first_pass = false;
            }            
            while (true);
        }

        static bool ParseArgs( string[] args, out string city, out bool single_instance )
        {
            city = null;
            single_instance = false;
            var valid_args = new Dictionary<string, int>() { { "-c", 1 }, { "-s", 1 }, { "--help", 1 } };  

            int i = 0;
            int L = args.Length;
            while (i < L)
            {
                if (args[i] == "-c") {
                    if( i + 1 < L ) {
                        city = args[i + 1]; i += 2;
                    }
                    else
                    {                    
                        PrintHelp(true, "Incorrect args!\nHere's the manual:" );
                        return false;
                    }
                }
                if (i < L && args[i] == "-s") { single_instance = true; ++i; }                
                if (i < L && args[i] == "--help")
                {                   
                    PrintHelp(true);
                    return false;
                }
                if ( i < L && !valid_args.TryGetValue( args[i], out int x ) )
                {                      
                    PrintHelp(true, "Incorrect args!\nHere's the manual:" );
                    return false;
                }
            }
            return true;
        }

        static string GetCityFromUser()
        {
            PrintLn("| Enter a city to see the weather:                                            |");
            PrintLn("+-----------------------------------------------------------------------------+");
            Console.Write(">>> ");
            return Console.ReadLine();
        }

        static bool CallAPIwithBackoff(string city, int [] backoff_intervals, out string result)
        {
            string subresult = "";
            foreach (int interval in backoff_intervals)
            {
                var code = CallAPI_GetJson( city, out subresult );               
                if( code == API_STATUS.OK )
                {
                    result = subresult; return true;
                }
                else if( code == API_STATUS.CITY_NOT_FOUND )
                {
                    PrintLn( "Sorry, city not found!" );
                    result = "";
                    return true;
                }
                else if( code == API_STATUS.API_UNAVAILABLE) 
                {
                    PrintLn( "Couldn't reach the api! Retrying in {0} seconds...", interval );
                    Thread.Sleep( interval * 1000 );
                }
            }
            PrintLn( "Failed to reach api. Exiting program." );
            result = "";            
            return false;            
        }

        static API_STATUS CallAPI_GetJson(string city, out string result)
        {
            result = null;
            var client = new HttpClient { BaseAddress = new Uri(UriString) };
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.GetAsync("weather?q=" + city + "&APPID=" + MYAPPID).Result;
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException)
            {
                return API_STATUS.CITY_NOT_FOUND;
            }
            catch(AggregateException a)
            {
                if(a.GetBaseException() is HttpRequestException)
                    PrintLn("Couldn't reach the api!");
                    return API_STATUS.API_UNAVAILABLE;
            }
            result = response.Content.ReadAsStringAsync().Result;
            return API_STATUS.OK;
        }

        static void ParseJson(  string json, out float temp, out float pressure, out float wind_speed, 
                                out float temp_min, out float temp_max, out float humidity, out int visibility, out string description)
        {
            Rootobject weatherDetails = JsonConvert.DeserializeObject<Rootobject>(json);

            pressure = weatherDetails.main.pressure;

            wind_speed = weatherDetails.wind.speed*(float)2.237;

            float kelvinTemp = weatherDetails.main.temp;
            temp = (int)((kelvinTemp - 273.15) * 1.8 + 32);

            kelvinTemp = weatherDetails.main.temp_min;
            temp_min = (int)((kelvinTemp - 273.15) * 1.8 + 32);

            kelvinTemp = weatherDetails.main.temp_max;
            temp_max = (int)((kelvinTemp - 273.15) * 1.8 + 32);

            humidity = weatherDetails.main.humidity;

            visibility = (int)(weatherDetails.visibility / (float)1609.344);

            description = weatherDetails.weather[0].description;
        }

        static void PrintWeatherInfo(float temp, float pressure, float wind_speed, string city,  float temp_min,  float temp_max,  float humidity,  int visibility,  string description )
        {
            PrintLn("+-----------------------------------------------------------------------------+");
            PrintLn("| Here's the weather in {0,-30}{1,25}", city + ":", "|");
            PrintLn("| Temprature: {0,-10} {1,54}", temp + " F", "|");
            PrintLn("| Temp min: {0, -10} {1,56}", temp_min + " F", "|");
            PrintLn("| Temp max: {0, -10} {1,56}", temp_max + " F", "|");
            PrintLn("| Pressure: {0, -10} {1,56}", pressure + " hPa", "|");
            PrintLn("| Humidity: {0, -10} {1,56}", humidity + " %", "|");
            PrintLn("| Wind Speed: {0, -10} {1,54}", wind_speed + " mph", "|");
            PrintLn("| Visibility: {0, -10} {1,54}", visibility + " miles", "|");
            PrintLn("| Description: {0, -40} {1,23}", description + " ", "|");            
            PrintLn("+-----------------------------------------------------------------------------+");
        }

        static void PrintLn(object str_to_print, params object[] args)
        {
            if( args.Length > 0)
                Console.WriteLine( string.Format(str_to_print.ToString(), args));
            else           
                Console.WriteLine(str_to_print);
        }      

        static void PrintHelp(bool clear_screen, string message = "")
        {
            if(clear_screen) { Console.Clear(); }
            if(message != "") { PrintLn( message ); }
            string[] help_lines = new string[] {
            "\nWeatherGrabber(1)               User Commands                    WeatherGrabber(1)\n",
            "NAME:\n\tWeatherGrabber\n" +
            "DESCRIPTION:\n\tDisplays the weather details of a given city.\n",
            "OPTIONS:\n",
            "\t-c [city]          Name of city.\n ",
            "\t-s                 Single instance; only grab data for specified city then quit.\n",                                 
            "\t--help             Info on how to run.\n" };

            foreach (string line in help_lines)
            {
                Console.Write(line);
            }
        }

        static void PrintHeader()
        {
            PrintLn("+-----------------------------------------------------------------------------+\n" +
                      "|                              WeatherGrabber 1.0                             |\n" +
                      "+ ----------------------------------------------------------------------------+");
        }
    }

    public class Rootobject
    {
        public Coord coord { get; set; }
        public Weather[] weather { get; set; }
        public string _base { get; set; }
        public Main main { get; set; }
        public int visibility { get; set; }
        public Wind wind { get; set; }
        public Clouds clouds { get; set; }
        public int dt { get; set; }
        public Sys sys { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public int cod { get; set; }
    }

    public class Coord
    {
        public float lon { get; set; }
        public float lat { get; set; }
    }

    public class Main
    {
        public float temp { get; set; }
        public int pressure { get; set; }
        public int humidity { get; set; }
        public float temp_min { get; set; }
        public float temp_max { get; set; }
    }

    public class Wind
    {
        public float speed { get; set; }
    }

    public class Clouds
    {
        public int all { get; set; }
    }

    public class Sys
    {
        public int type { get; set; }
        public int id { get; set; }
        public float message { get; set; }
        public string country { get; set; }
        public int sunrise { get; set; }
        public int sunset { get; set; }
    }

    public class Weather
    {
        public int id { get; set; }
        public string main { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
    }
}

